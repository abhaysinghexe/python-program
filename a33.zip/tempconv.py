def ctof(a):
 return((a*9/5)+32)
def ftoc(b):
 return((b-32)*5/9)