def area(x):
 return(22/7*x*x)
def perimeter(x):
 return(2*22/7*x)