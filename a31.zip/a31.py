import ap
r=int(input("Enter the radius of circle : "))
a=ap.area(r)
b=ap.perimeter(r)
print("area of circle : ",a)
print("perimeter of circle : ",b)